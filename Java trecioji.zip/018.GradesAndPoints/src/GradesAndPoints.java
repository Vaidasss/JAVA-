
import java.util.Scanner;

public class GradesAndPoints {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

       
        
        System.out.println("Type the points [0-60]: ");
		int TypedNumber = reader.nextInt();
		
		if ((TypedNumber >= 0 && TypedNumber <= 29))
			{ 
			System.out.println("failed");
		    }
		else if((TypedNumber >= 30 && TypedNumber <= 34 ))
		    {
			System.out.println("Grade: 1");
		    }
		else if((TypedNumber >= 35 && TypedNumber <= 39 ))
		   {
			System.out.println("Grade: 2");
		   }
		else if((TypedNumber >= 40 && TypedNumber <= 44 ))
		   {
			System.out.println("Grade: 3");
		   }
		else if((TypedNumber >= 45 && TypedNumber <= 49))
		   {
			System.out.println("Grade: 4");
		   }
		else if((TypedNumber >= 50 && TypedNumber <= 60))
		   {
			System.out.println("Grade: 5");
		   }
        reader.close();
    }
}
