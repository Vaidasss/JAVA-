
import java.util.Scanner;

public class AgeCheck {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        
        System.out.println("How old are you?: ");
		int typedOld = reader.nextInt();
		
		
		
	    if (typedOld >= 0 && typedOld <= 120)
		{ 
		System.out.println("OK");
	    }
	    
	    else 
	    {
	    System.out.println("Impossible!");	
	    }
	    
	    
	    
		
		
	    
        reader.close();
        

    }
}
