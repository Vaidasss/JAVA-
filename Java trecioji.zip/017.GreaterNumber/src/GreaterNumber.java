import java.util.Scanner;

public class GreaterNumber {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        
        System.out.println("Type the first number: ");
		int firstNumber = reader.nextInt();
		
		System.out.println("Type the second number: ");
		int secondNumber = reader.nextInt();
		
		int max;
		
		if (firstNumber > secondNumber)
		{ max = firstNumber;
		System.out.println( "Greater number: " + max);
		}
		
		else if (firstNumber < secondNumber)
		{ max = secondNumber;
		System.out.println("Greater number: " + max);
		}
		
		else
		System.out.println("The numbers are equal!");	
		
		
		

        
        
        reader.close();
    }
}
