
public class FromOneToHundred {

    public static void main(String[] args) {
        // Write your program here
    }
}
