import java.util.Scanner;
	public class Uzduotis_07 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
			/* nelabai supratau tik vieno dalyko. Ar man pačiam sąlygose įrašyti skaičius - kiek saldainių 
			 * kas turi gauti, ar palikti galimybę įrašyti ir kitokius saldainių skaičius. Anyway, apačioje,
			 * palieku ir kitą kodo dalį.
		*/
			
			  System.out.println("Įveskite devintokų skaičių:");
			  int devintokai = reader.nextInt(); 
			  
			  System.out.println("Įveskite nupirktų saldainių skaičių:");
			  int saldainiai = reader.nextInt(); 
			 
			 
		
			
			
			/* Sąlygoje prašoma įvesti rankiniu būdu, jei reikia taip, belieka sukeisti komentarų brūkšnius
			 * int devintokai = 7;
			 * int saldainiai = 23;*/
			int pokieksaldainiu = saldainiai / devintokai;
			int kieklikomokytojai = saldainiai % devintokai;
			
			
			
			
			System.out.println("Devintokai gavo po: " + pokieksaldainiu + " saldainius, mokytojai liko "+ kieklikomokytojai + " saldainiai.");
			
			
			
			reader.close();
			
			
		}

	}