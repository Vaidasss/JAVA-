
import java.util.Scanner;
	public class Uzduotis_06 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
			
			System.out.println("Įveskite dienų skaičių:");
			int vienaSav = 7;
			int dienuSk = reader.nextInt(); 
			
			int vienaSavaite = dienuSk / vienaSav;
			
			System.out.println("Gauta: " + vienaSavaite + " savaitės");
			
			
			
			reader.close();
			
			
		}

	}