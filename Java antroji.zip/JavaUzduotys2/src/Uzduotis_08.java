
import java.util.Scanner;
	public class Uzduotis_08 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
		    System.out.println("Kiek centų pabėrė kasininkė?:");
		    int centuPaberta = reader.nextInt(); 
		    int vienasEu = 100;
		    
		    int euruSkaicius = centuPaberta / vienasEu;
			int centuSkaicius = centuPaberta % vienasEu;
			
			
			System.out.println("Pirkėjui paberta " + euruSkaicius + " Eur " + centuSkaicius + " ct. ");
			
			
			
			reader.close();
			
			
		}

	}