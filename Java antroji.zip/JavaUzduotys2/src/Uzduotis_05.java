import java.util.Scanner;
	public class Uzduotis_05 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			int perValanda = 18;
			int perPara = perValanda * 24;
			int perSavaite = perPara * 7;
			
			
			System.out.println("Gauta: per dieną - " + perPara + ", " + "per savaitę " + perSavaite);
			 
			
			
			reader.close();
			
			
		}

	}