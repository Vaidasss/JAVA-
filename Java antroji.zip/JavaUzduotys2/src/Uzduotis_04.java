import java.util.Scanner;
	public class Uzduotis_04 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
			System.out.println("Įveskite atstumą km:");
			int atstumasKm = reader.nextInt(); 
			
			System.out.println("Įveskite atstumą m:");
			int atstumasM = reader.nextInt();
			
			int atstumasMetrais = 1000 * atstumasKm + atstumasM;
			
			
			System.out.println("Gauta " + atstumasMetrais + " m");
		    
		    
		    
			
			
			reader.close();
			
			
		}

	}