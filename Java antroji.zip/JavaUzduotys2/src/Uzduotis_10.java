
import java.util.Scanner;
	public class Uzduotis_10 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
		    System.out.println("Įveskite filmo pradžios valandą: ");
		    int filmoPradziaH = reader.nextInt(); // kada prasideda.
		    
		    System.out.println("Įveskite filmo pradžios minutę: ");
		    int filmoPradziosM = reader.nextInt(); //pradzios min.
		    
		    System.out.println("Įveskite filmo trukmės valandą:");
		    int filmoTrukmeH = reader.nextInt(); // kada prasideda.
		    
		    System.out.println("Įveskite filmo trukmės minutę:");
		    int filmoTrukmeM = reader.nextInt(); // kada prasideda.
		    
		    int reklamosLaikas = 30;
		    
		    int trukmeNuoPradziosH = filmoPradziaH + filmoTrukmeH; //gaunu filmo trukme valandomis.
		    int trukmeNuoPradziosM = filmoPradziosM + filmoTrukmeM + reklamosLaikas; // gaunu filmo laika minutemis.
		    
		    int vienaVal = 60;
		    
		     int grynosValandos = trukmeNuoPradziosM / vienaVal;  //reikia gauti minuciu valandoje skirtuma
		     int grynosValandos1 = grynosValandos + trukmeNuoPradziosH;
		     
		     int trukmeNuopradziosMin = trukmeNuoPradziosM % vienaVal;
		     
		     System.out.println("Filmo pabaiga: "  + grynosValandos1  + ":" +  trukmeNuopradziosMin + "h");
		     
		    
		    reader.close();
			
			
		}

	}
			
			
	