    import java.util.Scanner;
	public class Uzduotis_02 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
			System.out.println("Įveskite kampą a:");
			int pirmasKampas = reader.nextInt(); 
			
			System.out.println("Įveskite kampą b:");
		    int antrasKampas = reader.nextInt();
		    
		    int kampuSuma = 180;
	        
	        int nezinomasKampas = kampuSuma - pirmasKampas - antrasKampas ;
	        
	        System.out.println("Nežinomo kampo dydis:" + nezinomasKampas );
			
			
			
			reader.close();
			
			
		}

	}