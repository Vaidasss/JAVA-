import java.util.Scanner;
public class Uzduotis_01 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite kraštinę a:");
		int pirmaKrastine = reader.nextInt(); 
		
		System.out.println("Įveskite kraštinę b:");
	    int antraKrastine = reader.nextInt();
	    
	    System.out.println("Įveskite kraštinę c:");
        int treciaKrastine = reader.nextInt();
        
        int krastiniuPerimetras = pirmaKrastine + antraKrastine + treciaKrastine;
        
        System.out.println("Trikampio perimetras:" + krastiniuPerimetras);
		
		
		
		reader.close();
		
		
	}

}
      