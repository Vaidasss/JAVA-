
import java.util.Scanner;
	public class Uzduotis_09 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
		    System.out.println("Koks yra lėktuvo pakilimo laikas h?:");
		    int lektuvPakilimLaikasH = reader.nextInt(); 
		    System.out.println("Koks yra lėktuvo pakilimo laikas min?:");
		    int lektuvPakilimLaikasM = reader.nextInt();
		    
		    int vienaVal = 60;
		    int lektuvPakilimLaikasMin = vienaVal * lektuvPakilimLaikasH + lektuvPakilimLaikasM ;
		    
		    System.out.println("Įveskite numatomą skrydžio trukmę min: ");
		    int skrydzioTrukmeM = reader.nextInt();
		    
		    int nusileidimoLaikas = lektuvPakilimLaikasMin + skrydzioTrukmeM;
		    
		    int nusileidimoValanda = nusileidimoLaikas / vienaVal;
		    System.out.println("Nusileidimo valanda: " + nusileidimoValanda);
		    int nusileidimoMinute = nusileidimoLaikas % vienaVal;
		    System.out.println("Nusileidimo minutė: " + nusileidimoMinute);
		    
		    reader.close();
			
			
		}

	}