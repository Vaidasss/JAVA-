package javabandymas;

//@author Ibrahim Yesilay
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class javabandymas {  
  public static void main(String[] args) throws ParseException {
  Scanner giris = new Scanner(System.in);        
      System.out.println("g�n:");
      int d = giris.nextInt();
      System.out.println("ay:");
      int m = giris.nextInt();
      System.out.println("yil:");
      int y = giris.nextInt();
      String tarih;
      tarih = Integer.toString(d) + ":" + Integer.toString(m) + ":" + Integer.toString(y);  
      System.out.println("Tarih : " + tarih); 
      SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
      Date girilentarih = null;
      girilentarih = dateFormat.parse(tarih);
      System.out.println(dateFormat.format(girilentarih));      
  }   
}