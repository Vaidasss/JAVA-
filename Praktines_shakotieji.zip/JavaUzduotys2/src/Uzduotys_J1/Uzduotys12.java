package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys12 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		System.out.println("Įveskite kodinį skaičių ");
		int kodas = reader.nextInt();
		
		switch(kodas) {
		case 1:
			System.out.println("Saulėta");
			break;
		case 2:
			System.out.println("Lietinga");
			break;
		case 3:
			System.out.println("Vėjuota");
			break;
		case 4:
			System.out.println("Sniegas");
			break;
		default:
			System.out.println("Nėra tokia kodo");
		}
		 reader.close();
	}
	
}