package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys2 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite skaičių, iš kurio norėtumėte gauti taisyklingą kvadrato formą: ");
		int pirmasNum = reader.nextInt(); 
		
		if (pirmasNum % 4 == 0) {
        System.out.println("Iš šio skaičiaus kvadratą sudaryti galima! Jūs - genijus! ");
		}
		else 
		System.out.println("Iš šio skaičiaus, padaryti taisyklingo kvadrato neišeis! Sugalvokite kitą skaičių. ");
		
		
		reader.close();
		
		
	}

}