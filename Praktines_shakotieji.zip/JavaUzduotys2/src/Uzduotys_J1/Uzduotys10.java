package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys10 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite pirmąjį skaičių kurį reikia patikrinti: ");
		int pirmasS = reader.nextInt();
		System.out.println("Įveskite antrąjį skaičių kurį reikia patikrinti: ");
		int antrasS = reader.nextInt();
		System.out.println("Įveskite trečiąjį skaičių kurį reikia patikrinti: ");
		int treciasS = reader.nextInt();
		
		int skaicius1 = pirmasS % 2;
		int skaicius2 = antrasS % 2;
		int skaicius3 = treciasS % 2;
		
		if(skaicius1 != 0 && skaicius2 != 0 && skaicius3 != 0) {
		System.out.println("Tarp įvestų skaičių lyginių skaičių nėra! ");
		 }
		     
		    else
		    	System.out.println("Taip, yra vienas arba keli lyginiai skaičiai!");
		    reader.close();
	}
	
}