package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys3 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite prekės kainą: ");
		double prekiuKaina = Double.parseDouble(reader.nextLine());
		
		System.out.println("Įveskite prekių kiekį: ");
		int prekiuSkaicius = reader.nextInt(); 
		
		double sumaPadauginus = prekiuKaina * prekiuSkaicius;
	
		
		
		if (prekiuSkaicius >= 3) {
        System.out.format("Suma su nuolaida yra: " +"%.2f%n", (0.8 / 1 ) * sumaPadauginus) ;
		}
		else 
		System.out.println("Mokėtina suma yra: " + prekiuKaina * prekiuSkaicius );
		
		
		reader.close();
		
		
	}

}