package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys5 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite pažymį, kuris bus pakomentuotas: ");
		int pazymys = reader.nextInt();
		
		    if (pazymys == 10){
			System.out.println("Puikiai!");	
			}
		    else if(pazymys == 9){
				System.out.println("Labai gerai!");
			}
		    else if(pazymys == 8){
			    System.out.println("Gerai!");	
			}
		    else if(pazymys == 7){
				System.out.println("Vidutiniskai..");
			}
			else if (pazymys <= 6 && pazymys >= 1){
				System.out.println("Reikia daugiau pastangų!!! ");
			}
			else {
					System.out.println("Įvestas nekomentuojamas skaičius, pasirinkite skaičių nuo 1 iki 10 imtinai!! ");
				}
			
		
		reader.close();
		
		
	}

}