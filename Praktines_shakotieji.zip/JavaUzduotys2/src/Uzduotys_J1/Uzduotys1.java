package Uzduotys_J1;

import java.util.Scanner;
	public class Uzduotys1 {

		public static void main(String[] args) {
			
			Scanner reader = new Scanner(System.in);
			
			System.out.println("Įveskite sveikąjį skaičių, kurio šaknį norėtumėte gauti: ");
			int pirmasNum = reader.nextInt(); 
			
			if (pirmasNum <= 0) {
	        System.out.println("Šaknies ištraukti negalima, nes įvestas neigiamas skaičius! Pabandykite įvesti sveikąjį skaičių. ");
			}
			else if (pirmasNum > 0)
			System.out.println("Gauta " + (Math.sqrt(pirmasNum)));
			
			
			reader.close();
			
			
		}

	}