package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys11 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite pirmąjį skaičių kurį reikia patikrinti: ");
		int num1 = reader.nextInt();
		System.out.println("Įveskite antrąjį skaičių kurį reikia patikrinti: ");
		int num2 = reader.nextInt();
		System.out.println("Įveskite trečiąjį skaičių kurį reikia patikrinti: ");
		int num3= reader.nextInt();
		
		  if( num1 >= 100 && num2 >= 100 && num3 >= 100 ) {
	          System.out.println("visi trizenkliai");}

	      else if (num1 <= 99 && num2 <= 99 && num3 <= 99) {
	          System.out.println("Nėra triženklių skaičių");}
		        
	      else if(num1 <= 99 && num2 >= 100 && num3 >= 100 || num1 >= 100 && num2 >= 100 && num3 <= 99 || num1 >= 100 && num2 <= 99 && num3 >= 100) {   
	    	  System.out.println("Du skaičiai yra triženkliai");}
		        
	      else if(num1 <= 99 && num2 <= 99 && num3 >= 100 || num1 >= 100 && num2 <= 99 && num3 <= 99 || num1 <= 99 && num2 >= 100 && num3 <=99) {
	    	  System.out.println("Vienas iš šių skaičių yra triženklis"); }
		  
	      else
	          System.out.println("Įvesti keturženkliai arba neigiami skaičiai kurių patiktinti sistema negali");
		 
		reader.close();
	}
	
}