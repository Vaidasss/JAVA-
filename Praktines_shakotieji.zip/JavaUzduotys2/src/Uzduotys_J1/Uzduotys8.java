package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys8 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite skaičių, o mes patikrinsim - triženklis jis, ar - ne: ");
		int skaicius = reader.nextInt();
		
		    if(skaicius > 0 && skaicius < 10 || skaicius < 100){
				System.out.println("Šis skaičius nėra triženklis skaičius. ");
			}
		    else if (skaicius >= 100 && skaicius <= 999){
			    System.out.println("Taip! Šis skaičius yra triženklis! ");	
			} 
		    else {
		    	System.out.println("Šio skaičiaus sistema patikrinti negali");
		    }
		    reader.close();
	}
	
}