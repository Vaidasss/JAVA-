package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys7 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite kampo duomenis, pagal juos nustatysime - koks tai kampas: ");
		int kampas = reader.nextInt();
		
		 if(kampas == 90){
				System.out.println("Įvestas kampas yra statusis.");
			}
		    else if (kampas == 180){
			    System.out.println("Įvestas kampas yra ištiestinis. ");	
			} 
		    else if (kampas == 360) {
		    	System.out.println("Įvestas kampas yra pilnutinis.");
		    }
		    else if (kampas < 0) {
		    	System.out.println("Kampo dydis turi būti teigiamas skaičius.");
		    }
		    else {
		    System.out.println("Deja, tokio kampo nustatymų sistema neatpažįsta.");	
		    }
		    reader.close();
	}
	
}