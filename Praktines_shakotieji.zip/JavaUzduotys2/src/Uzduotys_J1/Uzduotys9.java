package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys9 {

	public static void main(String[] args) {
		/* Tikiuosi šia užduotį supratau teisingai*/
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite pirmosios atkarpos ilgį: ");
		int ilgis1 = reader.nextInt();
		System.out.println("Įveskite antrosios atkarpos ilgį: ");
		int ilgis2 = reader.nextInt();
		System.out.println("Įveskite trečiosios atkarpos ilgį: ");
		int ilgis3 = reader.nextInt();
		
		int pirmasIlgis = 3;
		int antrasIlgis = 4;
		int treciasIlgis = 5;
		
		    if(ilgis1 == pirmasIlgis && ilgis2 == antrasIlgis && ilgis3 == treciasIlgis){
				System.out.println("Iš šių skaičių galima sudaryti statujį trikampį!");
			}
		    
		    else {
		    	System.out.println("Iš šių atkarpų, stataus trikampio sudaryti negalima");
		    }
		    reader.close();
	}
	
}