package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys13 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		System.out.println("Įveskite mėnesio skaičių: ");
		int menesis = reader.nextInt();
		
		switch(menesis) {
		case 1:
		case 2:
			System.out.println("Žiema");
			break;
		case 3:
		case 4:
		case 5:
			System.out.println("Pavasaris");
			break;
		case 6:
		case 7:
		case 8:
			System.out.println("Vasara");
			break;
		case 9:
		case 10:	
		case 11:
			System.out.println("Ruduo");
			break;
		case 12:	
			System.out.println("Žiema");
			break;	
		default:
			System.out.println("Nėra tokio mėnesio ir tokio metų laiko.");
		}
		 reader.close();
	}
	
}