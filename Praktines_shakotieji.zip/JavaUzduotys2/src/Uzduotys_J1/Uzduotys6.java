package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys6 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite skaičių, kurį reikia patikrinti: ");
		int skaicius = reader.nextInt();
		
		     if(skaicius < 0){
				System.out.println("Įvestas skaičius yra neigiamas. ");
			}
		    else if (skaicius >= 1){
			    System.out.println("Įvestas skaičius yra teigiamas. ");	
			} 
		    else {
		    	
		    System.out.println("Jūs gavote nulį. ");	
		    }
		    reader.close();
	}
	
}
		