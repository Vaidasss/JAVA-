package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys14 {

	public static void main(String[] args) {
		
		
		Scanner reader = new Scanner(System.in);
		System.out.print("Įveskite pirmąjį skaičių:");
        int pirmasS = reader.nextInt();
        System.out.print("Įveskite antrąjį skaičių:");
        int antrasS = reader.nextInt();

        System.out.print("Įveskite vieną iš matematinių simbolių (+, -, *, /): ");
        char simbolis = reader.next().charAt(0);

        reader.close();
         double atsakymas;

        switch(simbolis)
        {
            case '+':
            	atsakymas = pirmasS + antrasS;
                break;

            case '-':
            	atsakymas = pirmasS - antrasS;
                break;

            case '*':
            	atsakymas = pirmasS * antrasS;
                break;

            case '/':
            	atsakymas = pirmasS / antrasS;
                break;

            default:
                System.out.printf("You have entered wrong operator");
                return;
        }

        System.out.println(pirmasS + " " +simbolis+ " " +antrasS+ " = " +atsakymas);
    }
}