package Uzduotys_J1;

import java.util.Scanner;
public class Uzduotys4 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		System.out.println("Įveskite norimų pervežti dėžių skaičių: ");
		int n = reader.nextInt(); 
		System.out.println("Įveskite kiek telpa dėžių į mašiną: ");
		int m = reader.nextInt();
		
	     int k = n / m ;   //kartai k, 
	   
	
		if(k % m > 0) {
		System.out.println(" Pervežimui reiks " + k);
		}
		
	
	     
	
		
		
		
		
		
		
		reader.close();
		
		
	}

}